 <div class="col-md-6">  
<form>
  <div class="form-group">
    <label for="formGroupExampleInput">Semester Name</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Semester Name">
  </div>
  
     <button type="submit" class="btn btn-primary mb-2">Submit</button>
</form>
 </div>

