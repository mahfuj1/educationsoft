

        
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar"><span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span></a> Panel Title</h3>
                </div>
                <div class="panel-body">
                     
 

                     

                    <!-- Jumbotron
                                    ================================================== -->
                    
                </div><!-- panel body -->
            </div>
       